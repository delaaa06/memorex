<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'username',
        'phone',
        'xp',
        'level',
        'bio',
        'avatar',
        'banner',
        'login_streak',
        'last_login',
        'total_likes',
        'total_komentars',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    public function posts()
    {
        return $this->hasMany(Post::class);
    }

    public function komentars()
    {
        return $this->hasMany(\App\Models\komentar::class, 'user_id');
    }

    public function feedbacks()
    {
        return $this->hasMany(Feedback::class);
    }
    
    public function activities()
    {
        return $this->hasMany(Activity::class)->latest();
    }

    public function likes()
    {
        return $this->hasMany(Like::class, 'user_id'); 
    }

    public function addXp($amount)
    {
        $this->xp += $amount;
        $this->checkLevelUp();
        $this->save();
    }

    public function checkLevelUp()
    {
        while ($this->xp >= $this->level * 1000 && $this->level < 15) {
            $this->level += 1;
        }
    }
}
