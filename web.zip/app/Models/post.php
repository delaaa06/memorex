<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Post extends Model
{
    protected $fillable = [
        'user_id',
        'judul',
        'kategori',
        'isi',
        'visibilitas',
        'gambar',
        'likes',
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function komentar(): HasMany
    {
        return $this->hasMany(komentar::class, 'post_id');
    }

    public function getGambarUrlAttribute()
    {
        return $this->gambar ? asset('storage/' . $this->gambar) : null;
    }

    public function isVideo()
    {
        if (!$this->gambar) return false;
        
        $extension = strtolower(pathinfo($this->gambar, PATHINFO_EXTENSION));
        return in_array($extension, ['mp4', 'mov', 'avi', 'webm', 'mkv']);
    }

    public function isImage()
    {
        if (!$this->gambar) return false;
        
        $extension = strtolower(pathinfo($this->gambar, PATHINFO_EXTENSION));
        return in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg']);
    }

    public function isVisibleTo($userId)
    {
        if ($this->visibilitas === 'public' || $this->visibilitas === 'anon') {
            return true;
        }
        
        if ($this->visibilitas === 'private') {
            return $this->user_id === $userId;
        }
        
        return false;
    }

    public function getAuthorNameAttribute()
    {
        if ($this->visibilitas === 'anon') {
            return 'Anonymous';
        }
        
        return $this->user->name ?? 'Unknown';
    }

    public function scopePublic($query)
    {
        return $query->where('visibilitas',[ 'public','anon']);
    }

    public function scopeByCategory($query, $category)
    {
        return $query->where('kategori', $category);
    }

    public function getFormattedDateAttribute()
    {
        return $this->created_at->format('d F Y');
    }

     public function komentars()
    {
        return $this->hasMany(komentar::class, 'post_id');
    }

    public function likes()
    {
        return $this->hasMany(Like::class, 'post_id');
    }

    public function isLikedBy($user)
    {
        if (!$user) return false;
        return $this->likes()->where('user_id', $user->id)->exists();
    }

    public function likesCount()
    {
        return $this->likes()->count();
    }
    
    public function komentarsCount()
    {
        return $this->komentars()->count();
    }

}